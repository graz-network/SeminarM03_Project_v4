
use $path/datasets/main_dataset.dta, clear



eststo clear


estpost sum gewinn_norm listenplatz_norm  if female==1
matrix meanf1=e(mean)
matrix list meanf1

estpost sum gewinn_norm listenplatz_norm if female==0
matrix meanf2=e(mean)
matrix list meanf2


estpost  ttest gewinn_norm listenplatz_norm, by(female)
estadd matrix meanf1
estadd matrix meanf2

esttab  using TableA2/tableA2.txt,  style(tab) replace order(listenplatz_norm gewinn_norm ) noobs cells("meanf1(fmt(3))  meanf2(fmt(3))   b(star fmt(3)) se(fmt(3)) count(fmt(0))") star(* 0.1 ** .05 *** 0.01) ///
collabels("Female candidate" "Male candidate" "Diff." "Std. Error" "Obs.") ///
varlabels(gewinn_norm "Rank improvement (normalized)" listenplatz_norm "Initial list rank (normalized)") ///






