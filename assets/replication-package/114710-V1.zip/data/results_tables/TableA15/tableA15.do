



use $path/datasets/characteristics_mixed_and_single_gender_municipalities.dta, clear



estpost sum  log_bevoelkerung log_flaeche  log_debt_pc log_tottaxrev_pc log_gemeinde_beschaef_pc  log_female_sh_gem_besch   log_tot_beschaeft_pc log_female_share_totbesch   log_prod_share_tot       log_female_share_prod    if single_gender_uni==0
matrix meanf1=e(mean)
matrix list meanf1
estpost sum log_bevoelkerung log_flaeche  log_debt_pc log_tottaxrev_pc log_gemeinde_beschaef_pc  log_female_sh_gem_besch   log_tot_beschaeft_pc log_female_share_totbesch   log_prod_share_tot       log_female_share_prod     if single_gender_uni==1
matrix meanf2=e(mean)
matrix list meanf2


estpost ttest log_bevoelkerung log_flaeche  log_debt_pc log_tottaxrev_pc log_gemeinde_beschaef_pc  log_female_sh_gem_besch   log_tot_beschaeft_pc log_female_share_totbesch   log_prod_share_tot       log_female_share_prod   , by(single_gender_uni)
estadd matrix meanf1
estadd matrix meanf2


esttab  using TableA15/TableA15.txt, replace order(log_bevoelkerung log_flaeche  log_debt_pc log_tottaxrev_pc log_gemeinde_beschaef_pc  log_female_sh_gem_besch   log_tot_beschaeft_pc log_female_share_totbesch   log_prod_share_tot       log_female_share_prod    ) ///
cells("meanf1(fmt(3))  meanf2(fmt(3))   b(star fmt(3)) se(fmt(3)) count(fmt(0))") star(* 0.1 ** .05 *** 0.01) ///
collabels(  "Mixed-gender" "Single-gender"  "Diff." "Std. Error" "Obs.") ///
varlabels( log_bevoelkerung "Log(population)" log_flaeche "Log(land area)"  log_debt_pc "Log(debt p.c.)" log_tottaxrev_pc "Log(tax revenues p.c.)" log_tot_beschaeft_pc "Log(total employment p.c.)" log_female_share_totbesch "Log(female share, local gov. employment)"  log_gemeinde_beschaef_pc  "Log(public employment p.c.)" log_female_sh_gem_besch "Log(female share, local gov. employment)"       log_prod_share_tot "Log(manufacturing / total employment)" log_female_share_prod "Log(share female, manufacturing)") /// 
  






