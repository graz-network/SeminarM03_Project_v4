



use $path/datasets/main_dataset.dta, clear

* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1
keep if female==1


bandwidth_and_weights, depvar(employed) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
ivreg2 employed female_mayor margin_1 inter_1   if abs(margin_1)<$bw_opt  [pw=weight] , r cluster(gkz ) partial(margin_1 inter_1 )
est store m1
estadd local bw "CCT"
estadd local degree "Linear"
estadd local bw_length  $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum employed if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)



bandwidth_and_weights, depvar(selfemployed) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
ivreg2 selfemployed female_mayor margin_1 inter_1   if abs(margin_1)<$bw_opt  [pw=weight] , r cluster(gkz ) partial(margin_1 inter_1 )
est store m2
estadd local bw "CCT"
estadd local degree "Linear"
estadd local bw_length  $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum selfemployed if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)




bandwidth_and_weights, depvar(student) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
ivreg2 student female_mayor margin_1 inter_1   if abs(margin_1)<$bw_opt  [pw=weight] , r cluster(gkz ) partial(margin_1 inter_1 )
est store m3
estadd local bw "CCT"
estadd local degree "Linear"
estadd local bw_length  $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum student if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)



bandwidth_and_weights, depvar(retired) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
ivreg2 retired female_mayor margin_1 inter_1   if abs(margin_1)<$bw_opt  [pw=weight] , r cluster(gkz ) partial(margin_1 inter_1 )
est store m4
estadd local bw "CCT"
estadd local degree "Linear"
estadd local bw_length  $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum retired if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)



bandwidth_and_weights, depvar(housewifehusband) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
ivreg2 housewifehusband female_mayor margin_1 inter_1   if abs(margin_1)<$bw_opt  [pw=weight] , r cluster(gkz ) partial(margin_1 inter_1 )
est store m5
estadd local bw "CCT"
estadd local degree "Linear"
estadd local bw_length  $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum housewifehusband if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)



********************************************************************************************************************************************
* table 



esttab  m1 m2 m3 m4 m5  using TableA13/tableA13_PanelC.txt, replace style(tab) order( ) mlabel(,none) ///
cells(b(label(coef.) star fmt(%8.3f) ) se(label((z)) par fmt(%6.3f))) ///
collabels(none) ///
keep (female_mayor) ///
stats(bw bw_length degree N num_of_elections  N_clust mean_depvar sd_depvar , layout( @ @ @ @ @ @ `""@ (@)""' )  fmt( %~#s %9.2f %~# %9.0g %9.0g %9.0f %9.2f %9.2f  ) ///
labels("Bandwidth type" "Bandwidth size" "Polynomial"   "N" "Elections" "Municipalities" "Mean (SD)"  )) ///
  starlevels(* 0.10 ** 0.05 *** 0.01)  ///
  


