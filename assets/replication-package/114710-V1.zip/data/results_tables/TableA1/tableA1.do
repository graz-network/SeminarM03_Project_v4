


use $path/datasets/mayor_election_data.dta, clear


* identify election year and gender of first placed
destring election_year, gen(election_year_num)
* gen mayor_election_year=(jahr==election_year_num)
gen geschl_first_placed_num=(geschl_first_placed=="f" & geschl_first_placed!="")



* all major elections
unique gkz if mayor_election_year==1 , by(jahr) gen(gkz_by_mayor)



* mixed gender mayor elections
unique gkz if mayor_election_year==1 & rdd_sample==1, by(jahr) gen(gkz_by_election_rdd_sample)




* mixed gender and close mayor elections
unique gkz if mayor_election_year==1 &  rdd_sample==1 & abs(margin_1)<10, by(jahr) gen(gkz_by_mayor_rdd_sample_close)
 
* mixed gender and close mayor elections and female winner
unique gkz if mayor_election_year==1 &  rdd_sample==1 & abs(margin_1)<10 & geschl_first_placed_num==1, by(jahr) gen(gkz_by_mayor_rdd_sample_close_f)


* now collapse
collapse gkz_by_mayor  gkz_by_election_rdd_sample  gkz_by_mayor_rdd_sample_close gkz_by_mayor_rdd_sample_close_f , by(jahr)


* now we construct the sum of mayor elections over sample period

preserve
tempfile temp
collapse (sum) gkz_by_mayor   gkz_by_election_rdd_sample  gkz_by_mayor_rdd_sample_close gkz_by_mayor_rdd_sample_close_f,
save `temp', replace
restore
append using `temp'


* now format and label varialbes
tostring jahr, replace
replace jahr="Total" if _n==_N
label var jahr "Year"
label var gkz_by_mayor "All elections"
label var gkz_by_election_rdd_sample "Mixed-gender elections"
label var gkz_by_mayor_rdd_sample_close "Mixed-gender and close elections"
label var gkz_by_mayor_rdd_sample_close_f "Female victories, close mixed-gender elections"
format gkz* %20,0fc



export excel  using TableA1/tableA1.xls, firstrow(varl) replace
