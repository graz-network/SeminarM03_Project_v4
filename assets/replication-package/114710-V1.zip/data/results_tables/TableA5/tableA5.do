



use $path/datasets/main_dataset.dta, clear

* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1
keep if female==1



ivreg2 gewinn_norm  log_bevoelkerung log_flaeche  log_debt_pc log_tottaxrev_pc log_gemeinde_beschaef_pc  log_female_sh_gem_besch   log_tot_beschaeft_pc log_female_share_totbesch   log_prod_share_tot      log_female_share_prod  



predict predicted_rank_change, xb
* keep one observation per election given that each candidate has the same predicted value as municipality characteristics do not vary across candidates
bysort gkz jahr: keep if _n==1


* first determine optimal CCT BW
bandwidth_and_weights, depvar(predicted_rank_change) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)


ivreg2 predicted_rank_change female_mayor margin_1 inter_1   if abs(margin_1)<$bw_opt  [pw=weight], r cluster(gkz ) partial(margin_1 inter_1 )
est store m1
estadd local bw "CCT"
estadd local degree "Linear"
estadd local bw_length  $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum predicted_rank_change if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)


ivreg2 predicted_rank_change female_mayor margin_1 inter_1   if abs(margin_1)<$bw_half  [pw=weight_half], r cluster(gkz ) partial(margin_1 inter_1 )
est store m2
estadd local bw "CCT/2"
estadd local degree "Linear"
estadd local bw_length  $bw_half
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum predicted_rank_change if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)


ivreg2 predicted_rank_change female_mayor margin_1 inter_1   if abs(margin_1)<$bw_double  [pw=weight_double], r cluster(gkz ) partial(margin_1 inter_1 )
est store m3
estadd local bw "2CCT"
estadd local degree "Linear"
estadd local bw_length  $bw_double
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum predicted_rank_change if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)

* degree 1 with IK
* first determine optimal IK BW
bandwidth_and_weights, depvar(predicted_rank_change) var(margin_1)  bwmethod(IK) kernel(tri) degree(1)

ivreg2 predicted_rank_change female_mayor margin_1 inter_1   if abs(margin_1)<$bw_opt  [pw=weight] , r cluster(gkz ) partial(margin_1 inter_1 )
est store m4
estadd local bw "IK"
estadd local degree "Linear"
estadd local bw_length $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum predicted_rank_change if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)


* degree 2 with CCT
*  first determine  optimal BW for deg = 2
bandwidth_and_weights, depvar(predicted_rank_change) var(margin_1)  bwmethod(CCT) kernel(tri) degree(2)

ivreg2 predicted_rank_change female_mayor margin_1 inter_1 margin_2 inter_2   if abs(margin_1)<$bw_opt  [pw=weight] , r cluster(gkz ) partial(margin_1 inter_1 margin_2 inter_2)
est store m5
estadd local bw "CCT"
estadd local degree "Quadratic"
estadd local bw_length $bw_opt
unique gkz_jahr if e(sample)
estadd local num_of_elections  `"`r(sum)'"'
sum predicted_rank_change if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)
********************************************************************************************************************************************
* table 



esttab  m1 m2 m3 m4 m5 using TableA5/tableA5.txt, replace style(tab) order( ) mlabel(,none) ///
cells(b(label(coef.) star fmt(%8.3f) ) se(label((z)) par fmt(%6.3f))) ///
collabels(none) ///
keep (female_mayor) ///
stats(bw bw_length degree N num_of_elections  N_clust mean_depvar sd_depvar , layout( @ @ @ @ @ @ `""@ (@)""' )  fmt( %~#s %9.2f %~# %9.0g %9.0g %9.0f %9.2f %9.2f  ) ///
labels("Bandwidth type" "Bandwidth size" "Polynomial"   "N" "Elections" "Municipalities" "Mean (SD)"  )) ///
  starlevels(* 0.10 ** 0.05 *** 0.01)  ///
  


