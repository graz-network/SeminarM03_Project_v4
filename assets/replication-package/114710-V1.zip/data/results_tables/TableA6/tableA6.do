



use $path/datasets/mayor_election_data.dta, clear







keep if rdd_sample==1




quietly estpost summarize female_mayor male_mayor 
ttest female_mayor ==  male_mayor
post_ttest, colnames(Female Male Diff)
eststo res
esttab res using TableA6/MOV_100percent.txt, replace cells(" mu(fmt(%8.3f) star) se(par fmt(%8.3f)) p(fmt(%8.3f)) obs(fmt(%8.0f))") style(tab) noobs nonumber nomtitle ///
starlevels(* 0.10 ** 0.05 *** 0.01) 



quietly estpost summarize female_mayor male_mayor 
ttest female_mayor ==  male_mayor  if abs(margin_1)<=25
post_ttest, colnames(Female Male Diff)
eststo res
esttab res using TableA6/MOV_25percent.txt, replace cells(" mu(fmt(%8.3f) star) se( par fmt(%8.3f) ) p(fmt(%8.3f)) obs(fmt(%8.0f))") style(tab) noobs nonumber nomtitle ///
starlevels(* 0.10 ** 0.05 *** 0.01) 



quietly estpost summarize female_mayor male_mayor 
ttest female_mayor ==  male_mayor  if abs(margin_1)<=10
post_ttest, colnames(Female Male Diff)
eststo res
esttab res using TableA6/MOV_10percent.txt, replace cells("mu(fmt(%8.3f) star) se( par fmt(%8.3f)) p(fmt(%8.3f)) obs(fmt(%8.0f))") style(tab) noobs nonumber nomtitle ///
starlevels(* 0.10 ** 0.05 *** 0.01) 
