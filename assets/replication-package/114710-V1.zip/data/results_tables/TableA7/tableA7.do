



use $path/datasets/mayor_election_data.dta, clear





* keep only mixed-gender mayor elections
keep if rdd_sample==1





preserve
eret clear
estpost sum cdu_winner spd_winner  other_party_winner   if male_mayor==0
matrix meanf1=e(mean)
matrix list meanf1
estpost sum cdu_winner spd_winner  other_party_winner  if male_mayor==1
matrix meanf2=e(mean)
matrix list meanf2


estpost ttest cdu_winner spd_winner  other_party_winner , by(male_mayor)
estadd matrix meanf1
estadd matrix meanf2


esttab  using TableA7/party_affilation_all_mixed_gender_elections.txt, replace order(cdu_winner spd_winner other_party_winner  ) cells("meanf1(fmt(3))  meanf2(fmt(3))   b(star fmt(3)) se(fmt(3)) count(fmt(0))") star(* 0.1 ** .05 *** 0.01) ///
collabels( "Female mayor" "Male mayor" "Diff." "Std. Error" "Obs.") ///
varlabels(cdu_winner "CDU" spd_winner "SPD"  other_party_winner "Other"   ) 
  
restore





preserve
eret clear
keep if abs(margin_1)<10
estpost sum cdu_winner spd_winner  other_party_winner   if male_mayor==0
matrix meanf1=e(mean)
matrix list meanf1
estpost sum cdu_winner spd_winner  other_party_winner  if male_mayor==1
matrix meanf2=e(mean)
matrix list meanf2


estpost ttest cdu_winner spd_winner  other_party_winner , by(male_mayor)
estadd matrix meanf1
estadd matrix meanf2


esttab  using TableA7/party_affilation_mixed_gender_elections_with_MOV10.txt, replace order(cdu_winner spd_winner other_party_winner  ) cells("meanf1(fmt(3))  meanf2(fmt(3))   b(star fmt(3)) se(fmt(3)) count(fmt(0))") star(* 0.1 ** .05 *** 0.01) ///
collabels( "Female mayor" "Male mayor" "Diff." "Std. Error" "Obs.") ///
varlabels(cdu_winner "CDU" spd_winner "SPD"  other_party_winner "Other"   ) 

restore
