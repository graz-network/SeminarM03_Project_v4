
use $path/datasets/main_dataset.dta, clear


eret clear
keep if female==1
estpost sum gewinn_norm listenplatz_norm age non_university_phd university phd architect businessmanwoman  engineer lawyer  civil_administration  teacher  employed selfemployed student retired housewifehusband


esttab using Table1/Table1_PartB.txt , replace style(tab) ///
mlabel(,none) ///
cells("count(fmt(%6.0f)) mean(fmt(%6.3f)) sd(fmt(%6.3f)) min(fmt(%6.3f)) max(fmt(%6.3f)) ") ///
collabels(none) ///
varlabels( gewinn_norm "Rank change (normalized)" listenplatz_norm "Initial list rank (normalized)" age "Age" non_university_phd "High school" university "University" phd "Phd" architect "Architect" businessmanwoman "Businesswoman/-man"  engineer "Engineer" lawyer "Lawyer"  civil_administration "Civil administration"  teacher "Teacher"  employed "Employed" selfemployed "Self-employed" student "Student" retired "Retired" housewifehusband "Housewife/-husband"  ) ///
  







