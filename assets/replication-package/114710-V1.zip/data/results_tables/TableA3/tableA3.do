



use $path/datasets/main_dataset.dta, clear

keep if female==1





ivreg2 gewinn_norm female_mayor_full_sample, cluster(gkz)  r
est store m1
estadd local code "No"
estadd local year "No"
sum gewinn_norm if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)

xi: ivreg2 gewinn_norm female_mayor_full_sample i.jahr, cluster(gkz)  r partial(i.jahr)
est store m2
estadd local code "No"
estadd local year "Yes"
sum gewinn_norm if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)

xi: ivreg2 gewinn_norm female_mayor_full_sample i.gkz, cluster(gkz)  r partial(i.gkz)
est store m3
estadd local code "Yes"
estadd local year "No"
sum gewinn_norm if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)

xi: ivreg2 gewinn_norm female_mayor_full_sample i.gkz i.jahr, cluster(gkz)  r partial(i.gkz i.jahr)
est store m4
estadd local code "Yes"
estadd local year "Yes"
sum gewinn_norm if e(sample)
estadd scalar  mean_depvar =r(mean)
estadd scalar sd_depvar =r(sd)

********************************************************************************************************************************************
* table 



esttab  m1 m2 m3 m4 using TableA3/tableA3.txt, replace style(tab) order( ) mlabel(,none) ///
cells(b(label(coef.) star fmt(%8.3f) ) se(label((z)) par fmt(%6.3f))) ///
collabels(none) ///
keep (female_mayor_full_sample) ///
  stats(year code  N N_clust mean_depvar sd_depvar , layout( @ @ @ @ `""@ (@)""')  fmt( %~#s %~# %9.0g  %9.0f  %9.2f %9.2f ) ///
 labels("Year FE" "Municipality FE"    "N" "Municipalities" "Mean (SD)" )) ///
starlevels(* 0.10 ** 0.05 *** 0.01) ///


