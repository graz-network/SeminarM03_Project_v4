
* set global
global path "c:/Users/xxx/"
* set  adopath
adopath + $path/ado_files/


cd  $path/results_figures/




do Figure1/figure1.do

do Figure2/figure2.do

do Figure3/figure3.do

do FigureA1/figureA1.do

do FigureA2/figureA2.do

do FigureA3/figureA3.do

do FigureA4/figureA4.do

do FigureA5/figureA5_subfigure_a.do
do FigureA5/figureA5_subfigure_b.do

do FigureA6/figureA6.do

do FigureA7/figureA7.do

do FigureA8/figureA8_subfigure_a.do
do FigureA8/figureA8_subfigure_b.do

do FigureA9/figureA9.do

do FigureA10/figureA10.do





