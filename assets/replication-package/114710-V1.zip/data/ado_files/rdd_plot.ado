capture program drop rdd_plot
program define rdd_plot
	version 9.1
	syntax varlist [if] [in] , xtitle(string) bw(real) includedbw(real) title(string) control(varlist) binsize(real) [yscale(string )]  

marksample touse
preserve
****************************************************************************************************************************************************************
qui keep if `touse'
tokenize "`varlist'"
local variable `1' 
tokenize "`control'"
local c `1'
tempvar mean
tempvar bin


tempvar ul0
tempvar ll0

tempvar ul1
tempvar ll1

tempvar x0
tempvar s0
tempvar se0
tempvar x1
tempvar s1
tempvar se1


* make sample restrictions and generate bins
keep if abs(`c')<`includedbw'

gen `bin'=`c'-mod(`c',`binsize')+`binsize'/2
egen `mean'=mean(`variable'), by(`bin')




* generate confidence intervals


qui: lpoly `variable' `c' if `c'<0  , bw(`bw') deg(1)  n(100) gen(`x0' `s0') ci se(`se0') kernel( triangle  )
qui: lpoly `variable' `c' if `c'>=0 , bw(`bw')  deg(1)   n(100) gen(`x1' `s1') ci se(`se1') kernel( triangle  )



forvalues v=0/1 {
		gen `ul`v'' = `s`v'' + 1.96*`se`v''
		gen `ll`v'' = `s`v'' - 1.96*`se`v'' 
	}
	
	

* generate the RDD plot
	
qui: tw (rarea  `ul0' `ll0' `x0', bcolor(gs14) ) (rarea  `ul1' `ll1' `x1', bcolor(gs14) ) (scatter `mean' `bin', msymbol(circle) msize(large)    mcolor(black) )  (line `s0' `ul0' `ll0' `x0' , lwidth(thick) lcolor(red gray gray) lpattern(solid solid solid) )  (line `s1' `ul1' `ll1' `x1' , lwidth(thick) lcolor( red gray gray) lpattern(solid solid solid)), legend(off) xtitle("Closeness indicator") ytitle(`"`title'"')  xline(0) ylabel(`yscale') xlabel(-30(10)30)   xtitle(`"`xtitle'"') 

 restore
end	


