capture program drop bandwidth_and_weights
program define bandwidth_and_weights
	version 9.1
	syntax [if] [in] , depvar(varlist) var(varlist)  bwmethod(string) kernel(string) degree(real)

	capture: macro drop bw_opt bw_half bw_double
	capture: drop ind ind_half ind_double temp1 temp1_half temp1_double temp2 temp2_half temp2_double weight weight_half weight_double
	
	qui: rdrobust `depvar' `var'  , c(0) kernel(`kernel') p(`degree')   bwselect(`bwmethod')
	
	global bw_opt :   display %4.2f `e(h_bw)'
	global bw_half :  display %4.2f `e(h_bw)'/2
	global bw_double :  display %4.2f `e(h_bw)'*2


	gen temp1= `var'/ $bw_opt
	gen ind= abs(temp1)<=1
	gen temp2= 1-(abs(temp1))
	gen weight= temp2*ind



	gen temp1_half= `var'/ $bw_half
	gen ind_half= abs(temp1_half)<=1
	gen temp2_half= 1-(abs(temp1_half))
	gen weight_half= temp2_half*ind_half



	gen temp1_double= `var'/ $bw_double
	gen ind_double= abs(temp1_double)<=1
	gen temp2_double= 1-(abs(temp1_double))
	gen weight_double= temp2_double*ind_double
	

end	

