


capture program drop post_ttest
program define post_ttest, eclass
syntax, colnames(string)


matrix diff = r(mu_1) - r(mu_2)
matrix colnames diff = `colname'
ereturn matrix diff = diff

display "se_1 = " r(sd_1) / (r(N_1)^.5)
matrix se_1 = r(sd_1) / (r(N_1)^.5)
ereturn matrix se_1 = se_1
    
display "se_2 = " r(sd_2) / (r(N_2)^.5)
matrix se_2 = r(sd_2) / (r(N_2)^.5)
ereturn matrix se_2 = se_2

display "sd = " r(se) * (r(N_1)^.5)
matrix sd = r(se) * (r(N_1)^.5)
ereturn matrix sd = sd

display "p = " r(p) 
matrix p = r(p) 
ereturn matrix p1 = p

	
matrix	empty = .
ereturn matrix mempty = empty



matrix mu = r(mu_1), r(mu_2), e(diff)
matrix se = e(se_1), e(se_2), r(se)
matrix p = e(mempty), e(mempty),e(p1)
matrix obs = e(mempty), e(mempty), r(N_1)	


foreach var in  mu se  p obs{
    matrix colnames `var' = `colnames'
    matrix list `var'
    ereturn matrix `var' = `var'
}

end
