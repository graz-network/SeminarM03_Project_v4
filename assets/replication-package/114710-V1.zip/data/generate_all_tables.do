
* set global
global path "c:/Users/xxx/"
* set  adopath
adopath + $path/ado_files/


cd  $path/results_tables/


* Main tables
do Table1/table1_partA.do
do Table1/table1_partB.do

do Table2/table2.do

do Table3/table3.do

do Table4/table4_PanelA.do
do Table4/table4_PanelB.do
do Table4/table4_PanelC.do

do Table5/table5.do

do Table6/table6_PanelA.do
do Table6/table6_PanelB.do

do Table7/table7.do

do Table8/table8_PanelA.do
do Table8/table8_PanelB.do

do Table9/table9.do



** Apendix tables
do TableA1/tableA1.do

do TableA2/tableA2.do

do TableA3/tableA3.do

do TableA4/tableA4_PanelA.do
do TableA4/tableA4_PanelB.do

do TableA5/tableA5.do

do TableA6/tableA6.do

do TableA7/tableA7.do

do TableA8/tableA8.do

do TableA9/tableA9.do

do TableA10/tableA10_PanelA.do
do TableA10/tableA10_PanelB.do

do TableA11/tableA11.do



do TableA12/tableA12.do

do TableA13/tableA13_PanelA.do
do TableA13/tableA13_PanelB.do
do TableA13/tableA13_PanelC.do

do TableA14/tableA14_PanelA.do
do TableA14/tableA14_PanelB.do
do TableA14/tableA14_PanelC.do

do TableA15/tableA15.do

do TableA16/tableA16.do

do TableA17/tableA17_PanelA.do
do TableA17/tableA17_PanelB.do
do TableA17/tableA17_PanelC.do

do TableA18/tableA18.do

do TableA19/tableA19.do


