




use $path/datasets/main_dataset.dta, clear

* setup datasets: only one observation per municipality since turnout does not vary within municipality
bysort gkz jahr: keep if _n==1
keep if rdd_sample==1


bandwidth_and_weights, depvar(wahlbet) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  wahlbet, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Turnout") xtitle("Female mayoral candidate margin of victory (%)")  yscale(30(20)100)
graph export FigureA9/figureA9.pdf, replace

