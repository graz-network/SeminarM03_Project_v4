




use $path/datasets/dataset_with_lagged_rank_improvments.dta, clear



bandwidth_and_weights, depvar(gewinn_norm) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  gewinn_norm, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Rank improvement of women in previous election") xtitle("Female mayoral candidate margin of victory (%)") yscale(-5(2.5)5)  
graph export FigureA4/figureA4.pdf, replace

