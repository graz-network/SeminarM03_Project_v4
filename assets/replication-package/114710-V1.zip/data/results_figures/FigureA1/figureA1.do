




use $path/datasets/main_dataset.dta, clear

* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1
keep if female==1


ivreg2 gewinn_norm  log_bevoelkerung log_flaeche  log_debt_pc log_tottaxrev_pc log_gemeinde_beschaef_pc  log_female_sh_gem_besch   log_tot_beschaeft_pc log_female_share_totbesch   log_prod_share_tot      log_female_share_prod  



predict predicted_rank_change, xb
* keep one observation per election given that each candidate has the same predicted value as municipality characteristics do not vary across candidates
bysort gkz jahr: keep if _n==1


bandwidth_and_weights, depvar(predicted_rank_change) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  predicted_rank_change, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Predicted rank improvement of women") xtitle("Female mayoral candidate margin of victory (%)") yscale(-5(2.5)5)
graph export FigureA1/figureA1.pdf, replace
