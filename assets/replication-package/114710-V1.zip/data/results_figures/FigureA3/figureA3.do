




use $path/datasets/main_dataset.dta, clear



keep if rdd_sample==1
keep if elected==1

bandwidth_and_weights, depvar(female) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  female, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Liklihood of female council member") xtitle("Female mayoral candidate margin of victory (%)")   yscale(0.1(0.1)0.5) 
graph export FigureA3/figureA3.pdf, replace


