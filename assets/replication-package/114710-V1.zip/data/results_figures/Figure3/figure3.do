




use $path/datasets/main_dataset.dta, clear

* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1
keep if female==1


bandwidth_and_weights, depvar(listenplatz_norm) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  listenplatz_norm, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("List placement of women") xtitle("Female mayoral candidate margin of victory (%)")  yscale(25(5)50)
graph export Figure3/figure3.pdf, replace
