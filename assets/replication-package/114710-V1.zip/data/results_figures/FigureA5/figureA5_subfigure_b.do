




use $path/datasets/main_dataset.dta, clear

* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1
keep if female==1

bandwidth_and_weights, depvar(gewinn_dummy) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  gewinn_dummy, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Positive rank change of women") xtitle("Female mayoral candidate margin of victory (%)") yscale(0.2 (0.1)0.7)
graph export FigureA5/Figure5_subfigure_b.pdf, replace

