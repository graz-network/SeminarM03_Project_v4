




use $path/datasets/main_dataset.dta, clear






preserve
gen temp=1
bysort jahr: egen sum_cand=sum(temp)
gen female_cand=female*temp
bysort jahr: egen sum_fem_cand=sum(female_cand)
graph bar sum_cand sum_fem_cand, over(jahr) ytitle(Number of candidates)  blabel(total) legend(label (1 "All") label(2 "Female") ) bargap(3)
graph export Figure1/number_of_candidates.pdf, replace
restore





preserve
bysort gkz jahr: keep if _n==1
gen temp=1
bysort jahr: egen sum_cand=sum(temp)
graph bar sum_cand, over(jahr) ytitle(number of municipalities)  blabel(total) ylabel(0 (100) 450)
graph export Figure1/number_of_municipalities.pdf, replace 
restore



