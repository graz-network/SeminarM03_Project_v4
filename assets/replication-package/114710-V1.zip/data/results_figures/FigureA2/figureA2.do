




use $path/datasets/mayor_election_data, clear


* restrict sample to mixed-gender elections
keep if rdd_sample==1
* the McCrary plot
DCdensity margin_1, breakpoint(0) generate(Xj Yj r0 fhat se_fhat) nograph
local h=r(bandwidth)*2
local b=r(binsize)*2

DCdensity margin_1, breakpoint(0) generate(X1j Y1j r10 f1hat s1e_fhat)  h(`h') b(`b') graphname(FigureA2/figureA2.pdf)   
drop X1j Y1j r10 f1hat s1e_fhat

