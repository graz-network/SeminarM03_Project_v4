




use $path/datasets/main_dataset.dta, clear
adopath + c:/Users/tbaskaran/Dropbox/Bavaria_Gender/aej_rr/replication_files/ado_files/
* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1
keep if female==1

ivreg2 gewinn_norm  age non_university_phd university phd employed selfemployed student retired housewifehusband  architect businessmanwoman engineer lawyer civil_administration teacher
predict predicted_rank_change, xb


bandwidth_and_weights, depvar(predicted_rank_change) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  predicted_rank_change, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Predicted rank improvement of women") xtitle("Female mayoral candidate margin of victory (%)") yscale(-3(1)3)
graph export FigureA8/figureA8_subfigure_a.pdf, replace

