




use $path/datasets/main_dataset.dta, clear

* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1
keep if female==1


ivreg2 gewinn_norm  listenplatz_norm
predict predicted_rank_change, xb

bandwidth_and_weights, depvar(predicted_rank_change) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  predicted_rank_change, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Rank improvement  of women") xtitle("Female mayoral candidate margin of victory (%)") yscale(-5(2.5)5)  
graph export FigureA6/figureA6.pdf, replace

