




use $path/datasets/main_dataset.dta, clear

* setup datasets: keep only mixed-gender mayor elections and women candidates
keep if rdd_sample==1


bandwidth_and_weights, depvar(female) var(margin_1)  bwmethod(CCT) kernel(tri) degree(1)
rdd_plot  female, includedbw(30)  control(margin_1) binsize(3)  bw($bw_opt) title("Likelihood of female on the ballot") xtitle("Female mayoral candidate margin of victory (%)")   yscale(0.1(0.1)0.5)
graph export FigureA7/figureA7.pdf, replace

